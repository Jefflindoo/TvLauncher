package com.jefferson.tvlauncher.system

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.SystemClock
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import com.jefferson.tvlauncher.ui.MainActivity

/**
 * Faz o seu launcher "ganhar" do launcher do Google sem root:
 *  - onKeyEvent: se o aparelho entregar KEYCODE_HOME ao serviço, abre o launcher.
 *  - onAccessibilityEvent: se a janela do launcher do Google aparecer, reabre o seu.
 */
class HomeKeyService : AccessibilityService() {

    private var lastOpen = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg in STOCK_LAUNCHERS) openLauncher()
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (event.keyCode == KeyEvent.KEYCODE_HOME && event.action == KeyEvent.ACTION_UP) openLauncher()
        return false // não consome: se o sistema tratar, o evento de janela acima cobre o resto
    }

    override fun onInterrupt() = Unit

    private fun openLauncher() {
        val now = SystemClock.elapsedRealtime()
        if (now - lastOpen < 1000) return // debounce
        lastOpen = now
        startActivity(
            Intent(this, MainActivity::class.java)
                .addCategory(Intent.CATEGORY_HOME)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }

    private companion object {
        val STOCK_LAUNCHERS = setOf(
            "com.google.android.apps.tv.launcherx", // Google TV
            "com.google.android.tvlauncher"          // Android TV clássico
        )
    }
}
