package com.jefferson.tvlauncher.system

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.os.Handler
import android.os.Looper

/** Status de rede em tempo real via NetworkCallback (sem polling, sem custo de bateria/CPU). */
class NetworkMonitor(context: Context, private val onChange: (String) -> Unit) {

    private val cm = context.getSystemService(ConnectivityManager::class.java)
    private val main = Handler(Looper.getMainLooper())
    private var registered = false

    private val callback = object : ConnectivityManager.NetworkCallback() {
        override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) =
            post(describe(caps))

        override fun onLost(network: Network) = post("⚠  Sem rede")
    }

    fun start() {
        if (registered) return
        registered = true
        post(describe(cm.getNetworkCapabilities(cm.activeNetwork)))
        cm.registerDefaultNetworkCallback(callback)
    }

    fun stop() {
        if (!registered) return
        registered = false
        cm.unregisterNetworkCallback(callback)
    }

    private fun post(text: String) = main.post { onChange(text) }

    private fun describe(c: NetworkCapabilities?): String = when {
        c == null -> "⚠  Sem rede"
        !c.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) -> "⚠  Sem internet"
        c.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "🔌  Ethernet"
        c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "📶  Wi-Fi"
        else -> "🌐  Conectado"
    }
}
