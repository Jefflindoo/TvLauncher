package com.jefferson.tvlauncher.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * Papel de parede HD com baixo consumo de RAM: decodifica reduzido (<= 1920x1080) em RGB_565.
 * Fontes (nesta ordem):
 *  1) /sdcard/Android/data/<pacote>/files/wallpaper.jpg  (adb push)
 *  2) arquivo baixado por URL (filesDir/wallpaper.jpg)
 */
object WallpaperLoader {

    private fun internal(ctx: Context) = File(ctx.filesDir, "wallpaper.jpg")
    private fun external(ctx: Context) = ctx.getExternalFilesDir(null)?.let { File(it, "wallpaper.jpg") }

    fun load(ctx: Context, maxW: Int = 1920, maxH: Int = 1080): Bitmap? {
        val f = listOfNotNull(external(ctx), internal(ctx)).firstOrNull { it.exists() } ?: return null
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, bounds)
        if (bounds.outWidth <= 0) return null
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= maxW && bounds.outHeight / (sample * 2) >= maxH) sample *= 2
        val opts = BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.RGB_565
        }
        return BitmapFactory.decodeFile(f.path, opts)
    }

    /** Bloqueante: chame em Dispatchers.IO. */
    fun download(ctx: Context, url: String): Boolean {
        if (!url.startsWith("http://") && !url.startsWith("https://")) return false
        val tmp = File(ctx.cacheDir, "wp.tmp")
        return try {
            val c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 10000
            c.readTimeout = 20000
            c.inputStream.use { input -> tmp.outputStream().use { input.copyTo(it) } }
            c.disconnect()
            val b = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(tmp.path, b)
            if (b.outWidth <= 0) { tmp.delete(); false } else {
                clear(ctx)
                tmp.copyTo(internal(ctx), overwrite = true)
                tmp.delete()
                true
            }
        } catch (e: Exception) {
            tmp.delete()
            false
        }
    }

    fun clear(ctx: Context) {
        internal(ctx).delete()
        external(ctx)?.delete()
    }
}
