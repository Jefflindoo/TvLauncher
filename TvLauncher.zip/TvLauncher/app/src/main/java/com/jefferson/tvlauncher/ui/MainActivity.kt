package com.jefferson.tvlauncher.ui

import android.content.ActivityNotFoundException
import android.content.BroadcastReceiver
import android.content.ComponentCallbacks2
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.jefferson.tvlauncher.R
import com.jefferson.tvlauncher.data.AppCategory
import com.jefferson.tvlauncher.data.AppInfo
import com.jefferson.tvlauncher.data.AppRepository
import com.jefferson.tvlauncher.data.PrefsStore
import com.jefferson.tvlauncher.data.WallpaperLoader
import com.jefferson.tvlauncher.data.WeatherRepository
import com.jefferson.tvlauncher.system.NetworkMonitor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.Normalizer

class MainActivity : AppCompatActivity(), LauncherHost {

    private lateinit var prefs: PrefsStore
    private lateinit var repo: AppRepository
    private lateinit var weatherRepo: WeatherRepository
    private lateinit var network: NetworkMonitor

    private lateinit var wallpaper: ImageView
    private lateinit var txtWeather: TextView
    private lateinit var txtNetwork: TextView
    private lateinit var chipQuery: TextView
    private lateinit var favTitle: View
    private lateinit var favList: RecyclerView
    private lateinit var appGrid: RecyclerView

    private var allApps: List<AppInfo> = emptyList()
    private var tab: String = TAB_ALL
    private var query: String = ""
    private var pendingFocusKey: String? = null
    private var wallpaperFreed = false
    private var loadJob: Job? = null
    private val tabViews = LinkedHashMap<String, TextView>()

    // Favoritos ficam sempre compactos (ícones); o modo banner vale para a grade principal.
    private val favAdapter = AppAdapter(false, ::launchApp, ::showMenu)
    private val gridAdapter = AppAdapter(true, ::launchApp, ::showMenu)

    private val packageReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            i?.data?.schemeSpecificPart?.let { repo.invalidate(it) }
            reload(400) // vários eventos seguidos viram uma única recarga
        }
    }

    private val voiceLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == RESULT_OK) {
            val text = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!text.isNullOrBlank()) handleVoice(text)
        }
    }

    // ───────────── Ciclo de vida ─────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        setTheme(Themes.resId(PrefsStore(this).theme())) // tema de cor escolhido
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        prefs = PrefsStore(this)
        repo = AppRepository(this)
        weatherRepo = WeatherRepository(prefs)

        wallpaper = findViewById(R.id.wallpaper)
        txtWeather = findViewById(R.id.txtWeather)
        txtNetwork = findViewById(R.id.txtNetwork)
        favTitle = findViewById(R.id.favTitle)
        favList = findViewById(R.id.favList)
        appGrid = findViewById(R.id.appGrid)

        network = NetworkMonitor(this) { txtNetwork.text = it }

        favList.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        favList.adapter = favAdapter
        favList.itemAnimator = null
        appGrid.layoutManager = GridLayoutManager(this, 6)
        appGrid.adapter = gridAdapter
        appGrid.itemAnimator = null // sem animação de diff = foco estável e menos CPU
        appGrid.setHasFixedSize(true)
        appGrid.setItemViewCacheSize(12)
        applyViewMode()

        buildTabs()

        txtNetwork.setOnClickListener { openSystem(Settings.ACTION_WIFI_SETTINGS) }
        findViewById<View>(R.id.btnSettings).setOnClickListener { openSystem(Settings.ACTION_SETTINGS) }
        findViewById<View>(R.id.btnAjustes).setOnClickListener {
            SettingsMenu.show(this, this, hiddenApps(), prefs)
        }
        findViewById<View>(R.id.btnSearch).setOnClickListener {
            SearchMenu.show(this, query, ::applyQuery, ::startVoice)
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    query.isNotEmpty() -> applyQuery("")
                    tab != TAB_ALL -> select(TAB_ALL)
                    else -> appGrid.smoothScrollToPosition(0)
                }
            }
        })

        // Clima: a cada 30 min (2 min se falhar), só enquanto a tela está visível
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                while (true) {
                    val ok = updateWeather()
                    delay(if (ok) 30 * 60 * 1000L else 2 * 60 * 1000L)
                }
            }
        }

        loadWallpaper()
        reload()
    }

    override fun onStart() {
        super.onStart()
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_REPLACED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(this, packageReceiver, f, ContextCompat.RECEIVER_NOT_EXPORTED)
        try { network.start() } catch (e: Exception) { txtNetwork.text = "🌐  Rede" }
        if (wallpaperFreed) { wallpaperFreed = false; loadWallpaper() }
        if (allApps.isNotEmpty()) render() // atualiza "Recentes" ao voltar de um app
    }

    override fun onStop() {
        unregisterReceiver(packageReceiver)
        network.stop()
        super.onStop()
    }

    @Suppress("DEPRECATION")
    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level >= ComponentCallbacks2.TRIM_MEMORY_BACKGROUND) {
            wallpaper.setImageDrawable(null) // devolve ~4 MB enquanto outro app usa a RAM
            wallpaperFreed = true
        }
    }

    /** Botão Home com o launcher já aberto (launchMode=singleTask). */
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.hasCategory(Intent.CATEGORY_HOME)) {
            tab = TAB_ALL
            query = ""
            updateChip()
            updateTabs()
            render()
            appGrid.scrollToPosition(0)
            appGrid.post { appGrid.getChildAt(0)?.requestFocus() }
        }
    }

    // ───────────── Dados e renderização ─────────────

    private fun reload(delayMs: Long = 0) {
        loadJob?.cancel()
        loadJob = lifecycleScope.launch {
            if (delayMs > 0) delay(delayMs)
            allApps = withContext(Dispatchers.Default) { repo.load() }
            render()
        }
    }

    override fun refresh() = render()

    private fun resolved(): List<AppInfo> {
        val hidden = prefs.hidden()
        val favKeys = prefs.favorites()
        val overrides = prefs.categoryOverrides()
        return allApps.filter { it.key !in hidden }.map {
            it.copy(
                category = AppCategory.fromId(overrides[it.key]) ?: it.autoCategory,
                isFavorite = it.key in favKeys
            )
        }
    }

    private fun hiddenApps(): List<AppInfo> {
        val hidden = prefs.hidden()
        return allApps.filter { it.key in hidden }
    }

    private fun render() {
        val visible = resolved()
        val byKey = visible.associateBy { it.key }
        val recents = prefs.recents().mapNotNull { byKey[it] }

        val valid = when (tab) {
            TAB_ALL -> true
            TAB_RECENTS -> recents.isNotEmpty()
            else -> visible.any { it.category.id == tab }
        }
        if (!valid) { tab = TAB_ALL; updateTabs() }

        val shown = when {
            query.isNotEmpty() -> { val q = norm(query); visible.filter { norm(it.label).contains(q) } }
            tab == TAB_RECENTS -> recents
            tab == TAB_ALL -> visible
            else -> visible.filter { it.category.id == tab }
        }
        val favs = prefs.favorites().mapNotNull { byKey[it] }

        favTitle.isVisible = favs.isNotEmpty()
        favList.isVisible = favs.isNotEmpty()
        favAdapter.submitList(favs) {
            val k = pendingFocusKey ?: return@submitList
            pendingFocusKey = null
            val idx = favs.indexOfFirst { it.key == k }
            if (idx >= 0) {
                favList.scrollToPosition(idx)
                // pequeno atraso: o diálogo ainda está fechando e o sistema restauraria o foco antigo
                favList.postDelayed({
                    favList.findViewHolderForAdapterPosition(idx)?.itemView?.requestFocus()
                }, 200)
            }
        }
        gridAdapter.submitList(shown) { ensureFocus() }
    }

    /** Garante que o foco nunca fica "no vazio" (ex.: ao ocultar o item focado ou busca sem resultado). */
    private fun ensureFocus() {
        val f = currentFocus
        if (f == null || !f.isAttachedToWindow) {
            appGrid.post {
                val target: View? = appGrid.getChildAt(0)
                    ?: (if (chipQuery.isVisible) chipQuery else tabViews[tab])
                target?.requestFocus()
            }
        }
    }

    // ───────────── Abas (Todos, Recentes, categorias) ─────────────

    private fun buildTabs() {
        val container = findViewById<LinearLayout>(R.id.tabs)
        val entries = listOf(TAB_ALL to "Todos", TAB_RECENTS to "Recentes") +
            AppCategory.values().map { it.id to it.label }
        for ((id, label) in entries) {
            val tv = layoutInflater.inflate(R.layout.tab, container, false) as TextView
            tv.text = label
            tv.setOnClickListener { select(id) }
            container.addView(tv)
            tabViews[id] = tv
        }
        chipQuery = layoutInflater.inflate(R.layout.tab, container, false) as TextView
        chipQuery.visibility = View.GONE
        chipQuery.setOnClickListener { applyQuery("") }
        container.addView(chipQuery)
        updateTabs()
    }

    private fun updateTabs() = tabViews.forEach { (id, v) -> v.isSelected = (id == tab && query.isEmpty()) }

    private fun updateChip() {
        chipQuery.isVisible = query.isNotEmpty()
        chipQuery.text = "🔍  $query   ✕"
    }

    private fun select(id: String) {
        tab = id
        query = ""
        updateChip()
        updateTabs()
        render()
    }

    // ───────────── Busca (texto e voz) ─────────────

    private fun applyQuery(q: String) {
        query = q
        updateChip()
        updateTabs()
        render()
        if (q.isNotEmpty() && matchesOf(q).isEmpty()) {
            Toast.makeText(this, "Nenhum app encontrado", Toast.LENGTH_SHORT).show()
        }
    }

    private fun matchesOf(q: String): List<AppInfo> {
        val n = norm(q)
        return resolved().filter { norm(it.label).contains(n) }
    }

    private fun startVoice() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
            .putExtra(RecognizerIntent.EXTRA_PROMPT, "Diga o nome do app")
        try {
            voiceLauncher.launch(i)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "Reconhecimento de voz indisponível neste aparelho", Toast.LENGTH_LONG).show()
        }
    }

    /** "abrir netflix" -> se houver um único resultado, abre direto; senão filtra a grade. */
    private fun handleVoice(text: String) {
        val name = text.lowercase().removePrefix("abrir ").removePrefix("abra ").trim()
        val found = matchesOf(name)
        if (found.size == 1) launchApp(found[0]) else applyQuery(name)
    }

    private fun norm(s: String): String =
        Normalizer.normalize(s, Normalizer.Form.NFD).replace(ACCENTS, "").lowercase()

    // ───────────── Ações ─────────────

    private fun launchApp(app: AppInfo) {
        val intent = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LAUNCHER)
            .setComponent(app.component)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        try {
            prefs.recordLaunch(app.key)
            startActivity(intent)
        } catch (e: Exception) { // ActivityNotFound, Security... nunca derruba o launcher
            Toast.makeText(this, "Não foi possível abrir ${app.label}", Toast.LENGTH_SHORT).show()
            reload()
        }
    }

    private fun showMenu(app: AppInfo) = AppMenu.show(this, app, prefs) { focusKey ->
        pendingFocusKey = focusKey
        render()
    }

    private fun openSystem(action: String) {
        try {
            startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            Toast.makeText(this, "Atalho indisponível neste aparelho", Toast.LENGTH_SHORT).show()
        }
    }

    // ───────────── Aparência ─────────────

    private fun applyViewMode() {
        val banners = prefs.bannerMode()
        (appGrid.layoutManager as GridLayoutManager).spanCount = if (banners) 4 else 6
        gridAdapter.bannerMode = banners
    }

    override fun toggleBannerMode() {
        prefs.setBannerMode(!prefs.bannerMode())
        applyViewMode()
    }

    override fun applyTheme(index: Int) {
        prefs.setTheme(index)
        recreate()
    }

    // ───────────── Clima e papel de parede ─────────────

    private suspend fun updateWeather(): Boolean {
        val w = withContext(Dispatchers.IO) { weatherRepo.fetch() }
        txtWeather.text = if (w != null) "${w.emoji}  ${w.temp}°C  ·  ${w.city}" else "☁  Clima indisponível"
        return w != null
    }

    override fun changeCity(name: String) {
        lifecycleScope.launch {
            val loc = withContext(Dispatchers.IO) { weatherRepo.geocode(name) }
            if (loc == null) {
                Toast.makeText(this@MainActivity, "Cidade não encontrada", Toast.LENGTH_SHORT).show()
            } else {
                prefs.setLocation(loc)
                updateWeather()
            }
        }
    }

    private fun loadWallpaper() {
        lifecycleScope.launch {
            val bmp = withContext(Dispatchers.IO) { WallpaperLoader.load(this@MainActivity) }
            wallpaper.setImageBitmap(bmp) // null = volta ao gradiente do tema
        }
    }

    override fun setWallpaper(url: String) {
        lifecycleScope.launch {
            Toast.makeText(this@MainActivity, "Baixando imagem…", Toast.LENGTH_SHORT).show()
            val ok = withContext(Dispatchers.IO) { WallpaperLoader.download(this@MainActivity, url) }
            Toast.makeText(
                this@MainActivity,
                if (ok) "Papel de parede aplicado" else "Falha ao baixar a imagem",
                Toast.LENGTH_SHORT
            ).show()
            if (ok) loadWallpaper()
        }
    }

    override fun clearWallpaper() {
        WallpaperLoader.clear(this)
        loadWallpaper()
    }

    private companion object {
        const val TAB_ALL = "all"
        const val TAB_RECENTS = "recents"
        val ACCENTS = Regex("\\p{Mn}+")
    }
}
