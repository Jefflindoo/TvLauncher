package com.jefferson.tvlauncher.ui

import android.content.ActivityNotFoundException
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.jefferson.tvlauncher.R
import com.jefferson.tvlauncher.data.AppCategory
import com.jefferson.tvlauncher.data.AppInfo
import com.jefferson.tvlauncher.data.AppRepository
import com.jefferson.tvlauncher.data.PrefsStore
import com.jefferson.tvlauncher.data.WallpaperLoader
import com.jefferson.tvlauncher.data.WeatherRepository
import com.jefferson.tvlauncher.system.NetworkMonitor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity(), LauncherHost {

    private lateinit var prefs: PrefsStore
    private lateinit var repo: AppRepository
    private lateinit var weatherRepo: WeatherRepository
    private lateinit var network: NetworkMonitor

    private lateinit var wallpaper: ImageView
    private lateinit var txtWeather: TextView
    private lateinit var txtNetwork: TextView
    private lateinit var favTitle: View
    private lateinit var favList: RecyclerView
    private lateinit var appGrid: RecyclerView

    private var allApps: List<AppInfo> = emptyList()
    private var selected: AppCategory? = null
    private val tabViews = LinkedHashMap<AppCategory?, TextView>()

    private val favAdapter = AppAdapter(false, ::launchApp, ::showMenu)
    private val gridAdapter = AppAdapter(true, ::launchApp, ::showMenu)

    private val packageReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) = reload()
    }

    // ───────────── Ciclo de vida ─────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        prefs = PrefsStore(this)
        repo = AppRepository(this)
        weatherRepo = WeatherRepository(prefs)

        wallpaper = findViewById(R.id.wallpaper)
        txtWeather = findViewById(R.id.txtWeather)
        txtNetwork = findViewById(R.id.txtNetwork)
        favTitle = findViewById(R.id.favTitle)
        favList = findViewById(R.id.favList)
        appGrid = findViewById(R.id.appGrid)

        network = NetworkMonitor(this) { txtNetwork.text = it }

        favList.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        favList.adapter = favAdapter
        favList.itemAnimator = null
        appGrid.layoutManager = GridLayoutManager(this, 6)
        appGrid.adapter = gridAdapter
        appGrid.itemAnimator = null // sem animação de diff = foco estável e menos CPU
        appGrid.setHasFixedSize(true)

        buildTabs()

        txtNetwork.setOnClickListener { openSystem(Settings.ACTION_WIFI_SETTINGS) }
        findViewById<View>(R.id.btnSettings).setOnClickListener { openSystem(Settings.ACTION_SETTINGS) }
        findViewById<View>(R.id.btnAjustes).setOnClickListener {
            SettingsMenu.show(this, this, hiddenApps(), prefs)
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (selected != null) select(null) else appGrid.smoothScrollToPosition(0)
            }
        })

        // Clima: atualiza a cada 30 min, só enquanto a tela está visível
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                while (true) {
                    updateWeather()
                    delay(30 * 60 * 1000L)
                }
            }
        }

        loadWallpaper()
        reload()
    }

    override fun onStart() {
        super.onStart()
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_REPLACED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(this, packageReceiver, f, ContextCompat.RECEIVER_NOT_EXPORTED)
        network.start()
    }

    override fun onStop() {
        unregisterReceiver(packageReceiver)
        network.stop()
        super.onStop()
    }

    /** Botão Home pressionado com o launcher já aberto (launchMode=singleTask). */
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.hasCategory(Intent.CATEGORY_HOME)) {
            select(null)
            appGrid.scrollToPosition(0)
            appGrid.post { appGrid.getChildAt(0)?.requestFocus() }
        }
    }

    // ───────────── Dados e renderização ─────────────

    private fun reload() {
        lifecycleScope.launch {
            allApps = withContext(Dispatchers.Default) { repo.load() }
            render()
        }
    }

    override fun refresh() = render()

    private fun resolved(): List<AppInfo> {
        val hidden = prefs.hidden()
        val favKeys = prefs.favorites()
        val overrides = prefs.categoryOverrides()
        return allApps.filter { it.key !in hidden }.map {
            it.copy(
                category = AppCategory.fromId(overrides[it.key]) ?: it.autoCategory,
                isFavorite = it.key in favKeys
            )
        }
    }

    private fun hiddenApps(): List<AppInfo> {
        val hidden = prefs.hidden()
        return allApps.filter { it.key in hidden }
    }

    private fun render() {
        val visible = resolved()
        if (selected != null && visible.none { it.category == selected }) {
            selected = null
            updateTabs()
        }
        val favs = prefs.favorites().mapNotNull { k -> visible.firstOrNull { it.key == k } }
        val shown = selected?.let { c -> visible.filter { it.category == c } } ?: visible

        favTitle.isVisible = favs.isNotEmpty()
        favList.isVisible = favs.isNotEmpty()
        favAdapter.submitList(favs)
        gridAdapter.submitList(shown) { ensureFocus() }
    }

    /** Garante que o foco nunca fica "no vazio" (ex.: ao ocultar/desafixar o item focado). */
    private fun ensureFocus() {
        val f = currentFocus
        if (f == null || !f.isAttachedToWindow) {
            appGrid.post { appGrid.getChildAt(0)?.requestFocus() }
        }
    }

    // ───────────── Categorias (abas) ─────────────

    private fun buildTabs() {
        val container = findViewById<LinearLayout>(R.id.tabs)
        val entries: List<AppCategory?> = listOf(null) + AppCategory.values().toList()
        for (cat in entries) {
            val tv = layoutInflater.inflate(R.layout.tab, container, false) as TextView
            tv.text = cat?.label ?: "Todos"
            tv.setOnClickListener { select(cat) }
            container.addView(tv)
            tabViews[cat] = tv
        }
        updateTabs()
    }

    private fun updateTabs() = tabViews.forEach { (c, v) -> v.isSelected = (c == selected) }

    private fun select(cat: AppCategory?) {
        selected = cat
        updateTabs()
        render()
    }

    // ───────────── Ações ─────────────

    private fun launchApp(app: AppInfo) {
        val intent = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LAUNCHER)
            .setComponent(app.component)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        try {
            startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "Não foi possível abrir ${app.label}", Toast.LENGTH_SHORT).show()
            reload()
        }
    }

    private fun showMenu(app: AppInfo) = AppMenu.show(this, app, prefs) { render() }

    private fun openSystem(action: String) {
        try {
            startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "Atalho indisponível neste aparelho", Toast.LENGTH_SHORT).show()
        }
    }

    // ───────────── Clima e papel de parede ─────────────

    private suspend fun updateWeather() {
        val w = withContext(Dispatchers.IO) { weatherRepo.fetch() }
        txtWeather.text = if (w != null) "${w.emoji}  ${w.temp}°C  ·  ${w.city}" else "☁  Clima indisponível"
    }

    override fun changeCity(name: String) {
        lifecycleScope.launch {
            val loc = withContext(Dispatchers.IO) { weatherRepo.geocode(name) }
            if (loc == null) {
                Toast.makeText(this@MainActivity, "Cidade não encontrada", Toast.LENGTH_SHORT).show()
            } else {
                prefs.setLocation(loc)
                updateWeather()
            }
        }
    }

    private fun loadWallpaper() {
        lifecycleScope.launch {
            val bmp = withContext(Dispatchers.IO) { WallpaperLoader.load(this@MainActivity) }
            wallpaper.setImageBitmap(bmp) // null = volta ao gradiente padrão
        }
    }

    override fun setWallpaper(url: String) {
        lifecycleScope.launch {
            Toast.makeText(this@MainActivity, "Baixando imagem…", Toast.LENGTH_SHORT).show()
            val ok = withContext(Dispatchers.IO) { WallpaperLoader.download(this@MainActivity, url) }
            Toast.makeText(
                this@MainActivity,
                if (ok) "Papel de parede aplicado" else "Falha ao baixar a imagem",
                Toast.LENGTH_SHORT
            ).show()
            if (ok) loadWallpaper()
        }
    }

    override fun clearWallpaper() {
        WallpaperLoader.clear(this)
        loadWallpaper()
    }
}
