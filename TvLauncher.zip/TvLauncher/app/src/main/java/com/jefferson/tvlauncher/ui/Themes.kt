package com.jefferson.tvlauncher.ui

import com.jefferson.tvlauncher.R

object Themes {
    val names = listOf("Ciano futurista", "Roxo neon", "Verde matrix", "Âmbar", "Gótico vermelho")

    private val res = intArrayOf(
        R.style.Theme_TvLauncher,
        R.style.Theme_TvLauncher_Purple,
        R.style.Theme_TvLauncher_Green,
        R.style.Theme_TvLauncher_Amber,
        R.style.Theme_TvLauncher_Red
    )

    fun resId(index: Int) = res[index.coerceIn(0, res.size - 1)]
}
