package com.jefferson.tvlauncher.data

import android.content.ComponentName
import android.graphics.drawable.Drawable

data class AppInfo(
    val label: String,
    val packageName: String,
    val component: ComponentName,
    val icon: Drawable,
    val autoCategory: AppCategory,
    val category: AppCategory = autoCategory,
    val isFavorite: Boolean = false
) {
    /** Chave única e estável (um pacote pode ter mais de uma Activity de entrada). */
    val key: String get() = component.flattenToString()
}
