package com.jefferson.tvlauncher.ui

import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.animation.DecelerateInterpolator
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.jefferson.tvlauncher.R
import com.jefferson.tvlauncher.data.AppInfo

class AppAdapter(
    private val showStar: Boolean,
    private val onClick: (AppInfo) -> Unit,
    private val onMenu: (AppInfo) -> Unit
) : ListAdapter<AppInfo, AppAdapter.VH>(Diff) {

    /** true = cards 16:9 com banner (quando o app tem; senão ícone centralizado). */
    var bannerMode = false
        set(value) {
            if (field != value) {
                field = value
                notifyDataSetChanged()
            }
        }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val icon: ImageView = v.findViewById(R.id.icon)
        val label: TextView = v.findViewById(R.id.label)
    }

    override fun getItemViewType(position: Int) = if (bannerMode) 1 else 0

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val layout = if (viewType == 1) R.layout.item_banner else R.layout.item_app
        val v = LayoutInflater.from(parent.context).inflate(layout, parent, false)
        val vh = VH(v)
        if (viewType == 1) { // cantos arredondados no banner
            vh.icon.outlineProvider = ViewOutlineProvider.BACKGROUND
            vh.icon.clipToOutline = true
        }
        val interpolator = DecelerateInterpolator()
        // Zoom suave + elevação; a borda de destaque vem do selector bg_item (state_focused)
        v.setOnFocusChangeListener { view, hasFocus ->
            view.animate()
                .scaleX(if (hasFocus) 1.1f else 1f)
                .scaleY(if (hasFocus) 1.1f else 1f)
                .translationZ(if (hasFocus) 16f else 0f)
                .setDuration(140)
                .setInterpolator(interpolator)
                .start()
        }
        return vh
    }

    override fun onBindViewHolder(h: VH, position: Int) {
        val app = getItem(position)
        val banner = app.banner
        if (bannerMode && banner != null) {
            h.icon.scaleType = ImageView.ScaleType.CENTER_CROP
            h.icon.setPadding(0, 0, 0, 0)
            h.icon.setImageBitmap(banner)
        } else {
            h.icon.scaleType = ImageView.ScaleType.FIT_CENTER
            val pad = if (bannerMode) (22 * h.itemView.resources.displayMetrics.density).toInt() else 0
            h.icon.setPadding(pad, pad, pad, pad)
            h.icon.setImageBitmap(app.icon)
        }
        h.label.text = if (showStar && app.isFavorite) "★ ${app.label}" else app.label
        h.itemView.setOnClickListener { onClick(app) }
        // Segurar OK/Enter (ou tecla MENU) abre o menu do app
        h.itemView.setOnLongClickListener { onMenu(app); true }
        h.itemView.setOnKeyListener { _, code, ev ->
            if (code == KeyEvent.KEYCODE_MENU && ev.action == KeyEvent.ACTION_UP) { onMenu(app); true } else false
        }
    }

    private object Diff : DiffUtil.ItemCallback<AppInfo>() {
        override fun areItemsTheSame(a: AppInfo, b: AppInfo) = a.key == b.key
        override fun areContentsTheSame(a: AppInfo, b: AppInfo) =
            a.label == b.label && a.isFavorite == b.isFavorite && a.category == b.category &&
                a.icon === b.icon && a.banner === b.banner
    }
}
