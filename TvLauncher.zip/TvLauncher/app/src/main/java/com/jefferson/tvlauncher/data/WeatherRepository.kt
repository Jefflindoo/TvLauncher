package com.jefferson.tvlauncher.data

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Clima via Open-Meteo (gratuito, sem chave de API e sem anúncios).
 * Sem cidade configurada, usa localização aproximada pelo IP (ipwho.is).
 */
class WeatherRepository(private val prefs: PrefsStore) {

    data class Weather(val temp: Int, val emoji: String, val city: String)

    /** Bloqueante: chame em Dispatchers.IO. */
    fun fetch(): Weather? {
        return try {
            val loc = prefs.location()
                ?: ipLocation()?.also { prefs.setLocation(it) }
                ?: return null
            val url = "https://api.open-meteo.com/v1/forecast?latitude=${loc.lat}" +
                "&longitude=${loc.lon}&current=temperature_2m,weather_code&timezone=auto"
            val cur = JSONObject(get(url)).getJSONObject("current")
            Weather(
                temp = Math.round(cur.getDouble("temperature_2m")).toInt(),
                emoji = emojiFor(cur.getInt("weather_code")),
                city = loc.city
            )
        } catch (e: Exception) {
            null
        }
    }

    fun geocode(name: String): PrefsStore.Location? {
        return try {
            val q = URLEncoder.encode(name, "UTF-8")
            val json = JSONObject(
                get("https://geocoding-api.open-meteo.com/v1/search?name=$q&count=1&language=pt&format=json")
            )
            val r = json.optJSONArray("results")?.optJSONObject(0) ?: return null
            PrefsStore.Location(r.getString("name"), r.getDouble("latitude"), r.getDouble("longitude"))
        } catch (e: Exception) {
            null
        }
    }

    private fun ipLocation(): PrefsStore.Location? {
        val j = JSONObject(get("https://ipwho.is/"))
        if (!j.optBoolean("success", false)) return null
        return PrefsStore.Location(j.optString("city", "Local"), j.getDouble("latitude"), j.getDouble("longitude"))
    }

    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 8000
        return try {
            c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    /** Códigos WMO do Open-Meteo. */
    private fun emojiFor(code: Int) = when (code) {
        0 -> "☀️"
        1, 2 -> "⛅"
        3 -> "☁️"
        45, 48 -> "🌫️"
        in 51..57 -> "🌦️"
        in 61..67, in 80..82 -> "🌧️"
        in 71..77, 85, 86 -> "❄️"
        in 95..99 -> "⛈️"
        else -> "🌡️"
    }
}
