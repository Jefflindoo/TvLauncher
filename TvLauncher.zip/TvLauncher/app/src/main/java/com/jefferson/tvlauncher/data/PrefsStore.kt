package com.jefferson.tvlauncher.data

import android.content.Context

/** Toda a persistência do launcher (SharedPreferences, leve e síncrona na leitura). */
class PrefsStore(context: Context) {

    data class Location(val city: String, val lat: Double, val lon: Double)

    private val p = context.getSharedPreferences("launcher", Context.MODE_PRIVATE)

    private fun lines(key: String): List<String> =
        (p.getString(key, "") ?: "").split("\n").filter { it.isNotBlank() }

    private fun save(key: String, v: Collection<String>) =
        p.edit().putString(key, v.joinToString("\n")).apply()

    // ---- Favoritos (ordem preservada) ----
    fun favorites(): List<String> = lines("fav")
    fun toggleFavorite(key: String) {
        val l = favorites().toMutableList()
        if (!l.remove(key)) l.add(key)
        save("fav", l)
    }

    // ---- Apps ocultos ----
    fun hidden(): Set<String> = lines("hidden").toSet()
    fun setHidden(key: String, hide: Boolean) {
        val s = hidden().toMutableSet()
        if (hide) s.add(key) else s.remove(key)
        save("hidden", s)
    }

    // ---- Categoria definida pelo usuário ----
    fun categoryOverrides(): Map<String, String> = lines("cats").mapNotNull {
        val i = it.indexOf('|')
        if (i < 0) null else it.substring(0, i) to it.substring(i + 1)
    }.toMap()

    fun setCategory(key: String, cat: AppCategory?) {
        val m = categoryOverrides().toMutableMap()
        if (cat == null) m.remove(key) else m[key] = cat.id
        save("cats", m.map { "${it.key}|${it.value}" })
    }

    // ---- Localização do clima ----
    fun location(): Location? {
        val city = p.getString("city", null) ?: return null
        val lat = p.getString("lat", null)?.toDoubleOrNull() ?: return null
        val lon = p.getString("lon", null)?.toDoubleOrNull() ?: return null
        return Location(city, lat, lon)
    }

    fun setLocation(l: Location) {
        p.edit().putString("city", l.city)
            .putString("lat", l.lat.toString())
            .putString("lon", l.lon.toString()).apply()
    }
}
