package com.jefferson.tvlauncher.data

import android.content.pm.ApplicationInfo
import android.os.Build

/** Classificação automática. O usuário pode sobrescrever pelo menu do app. */
object Categorizer {

    private val STREAMING_PKGS = setOf(
        "com.netflix.ninja",
        "com.google.android.youtube.tv",
        "com.google.android.youtube.tvmusic",
        "com.google.android.videos",
        "com.amazon.amazonvideo.livingroom",
        "com.disney.disneyplus",
        "com.spotify.tv.android",
        "com.plexapp.android",
        "com.hulu.livingroomplus",
        "com.apple.atve.androidtv.appletv",
        "com.wbd.stream",
        "org.videolan.vlc"
    )

    @Suppress("DEPRECATION")
    fun detect(ai: ApplicationInfo): AppCategory {
        if (ai.packageName in STREAMING_PKGS) return AppCategory.STREAMING
        if (Build.VERSION.SDK_INT >= 26) {
            when (ai.category) {
                ApplicationInfo.CATEGORY_VIDEO,
                ApplicationInfo.CATEGORY_AUDIO -> return AppCategory.STREAMING
                ApplicationInfo.CATEGORY_GAME -> return AppCategory.GAMES
                ApplicationInfo.CATEGORY_PRODUCTIVITY,
                ApplicationInfo.CATEGORY_MAPS,
                ApplicationInfo.CATEGORY_IMAGE -> return AppCategory.UTILITIES
            }
        }
        if (ai.flags and ApplicationInfo.FLAG_IS_GAME != 0) return AppCategory.GAMES
        if (ai.flags and ApplicationInfo.FLAG_SYSTEM != 0) return AppCategory.UTILITIES
        return AppCategory.OTHER
    }
}
