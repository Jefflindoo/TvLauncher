package com.jefferson.tvlauncher.data

enum class AppCategory(val id: String, val label: String) {
    STREAMING("streaming", "Streaming"),
    GAMES("games", "Jogos"),
    UTILITIES("utils", "Utilitários"),
    OTHER("other", "Outros");

    companion object {
        fun fromId(id: String?): AppCategory? = values().firstOrNull { it.id == id }
    }
}
