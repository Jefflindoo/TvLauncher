package com.jefferson.tvlauncher.ui

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.text.InputType
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import com.jefferson.tvlauncher.R
import com.jefferson.tvlauncher.data.AppCategory
import com.jefferson.tvlauncher.data.AppInfo
import com.jefferson.tvlauncher.data.PrefsStore

/** Ações que os menus pedem à tela principal. */
interface LauncherHost {
    fun refresh()
    fun changeCity(name: String)
    fun setWallpaper(url: String)
    fun clearWallpaper()
    fun toggleBannerMode()
    fun applyTheme(index: Int)
}

private fun builder(a: Activity) = AlertDialog.Builder(a, R.style.TvDialog)

private fun openSafely(a: Activity, intent: Intent) {
    try {
        a.startActivity(intent)
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(a, "Não disponível neste aparelho", Toast.LENGTH_SHORT).show()
    } catch (e: SecurityException) {
        Toast.makeText(a, "O sistema bloqueou esta ação", Toast.LENGTH_SHORT).show()
    }
}

/** Menu de um app. onChanged recebe a chave a re-focar (ao reordenar favoritos) ou null. */
object AppMenu {

    fun show(a: Activity, app: AppInfo, prefs: PrefsStore, onChanged: (String?) -> Unit) {
        val actions = mutableListOf<Pair<String, () -> Unit>>()
        actions += (if (app.isFavorite) "Desafixar dos favoritos" else "Fixar nos favoritos") to {
            prefs.toggleFavorite(app.key); onChanged(null)
        }
        if (app.isFavorite) {
            actions += "◀  Mover favorito para a esquerda" to {
                prefs.moveFavorite(app.key, -1); onChanged(app.key)
            }
            actions += "Mover favorito para a direita  ▶" to {
                prefs.moveFavorite(app.key, +1); onChanged(app.key)
            }
        }
        actions += "Mover para categoria…" to { pickCategory(a, app, prefs, onChanged) }
        actions += "Ocultar da tela inicial" to { prefs.setHidden(app.key, true); onChanged(null) }
        actions += "Dados e informações do app" to {
            openSafely(a, Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.parse("package:${app.packageName}")))
        }
        actions += "Desinstalar" to {
            openSafely(a, Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.packageName}")))
        }

        builder(a).setTitle(app.label)
            .setItems(actions.map { it.first }.toTypedArray()) { _, i -> actions[i].second() }
            .show()
    }

    private fun pickCategory(a: Activity, app: AppInfo, prefs: PrefsStore, onChanged: (String?) -> Unit) {
        val cats = AppCategory.values()
        val items = cats.map { it.label }.toTypedArray() + "Automático (padrão)"
        builder(a).setTitle("Categoria de ${app.label}").setItems(items) { _, i ->
            prefs.setCategory(app.key, cats.getOrNull(i))
            onChanged(null)
        }.show()
    }
}

/** Busca por texto (com atalho para voz). */
object SearchMenu {

    fun show(a: Activity, current: String, onQuery: (String) -> Unit, onVoice: () -> Unit) {
        val et = EditText(a).apply {
            hint = "Nome do app"
            setText(current)
            inputType = InputType.TYPE_CLASS_TEXT
            imeOptions = EditorInfo.IME_ACTION_SEARCH
            setSingleLine()
            setTextColor(ContextCompat.getColor(a, R.color.text_primary))
            setHintTextColor(ContextCompat.getColor(a, R.color.text_secondary))
        }
        val dlg = builder(a).setTitle("Buscar app").setView(et)
            .setPositiveButton("Buscar") { _, _ -> onQuery(et.text.toString().trim()) }
            .setNeutralButton("🎤 Voz") { _, _ -> onVoice() }
            .setNegativeButton("Limpar") { _, _ -> onQuery("") }
            .create()
        et.setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_SEARCH) {
                onQuery(et.text.toString().trim()); dlg.dismiss(); true
            } else false
        }
        dlg.show()
    }
}

/** Menu "Ajustes" do launcher. */
object SettingsMenu {

    fun show(a: Activity, host: LauncherHost, hiddenApps: List<AppInfo>, prefs: PrefsStore) {
        val items = arrayOf(
            "Tema de cor (${Themes.names[prefs.theme().coerceIn(0, Themes.names.size - 1)]})",
            "Visual dos apps: ${if (prefs.bannerMode()) "Banners 16:9" else "Ícones"} (trocar)",
            "Cidade do clima (${prefs.location()?.city ?: "automática"})",
            "Papel de parede por URL",
            "Remover papel de parede",
            "Apps ocultos (${hiddenApps.size})",
            "Botão Home: ativar Acessibilidade"
        )
        builder(a).setTitle("Ajustes").setItems(items) { _, i ->
            when (i) {
                0 -> builder(a).setTitle("Tema de cor")
                    .setItems(Themes.names.toTypedArray()) { _, t -> host.applyTheme(t) }.show()
                1 -> host.toggleBannerMode()
                2 -> prompt(a, "Cidade", "Ex.: São Paulo") { host.changeCity(it) }
                3 -> prompt(a, "URL da imagem (JPG/PNG)", "https://…") { host.setWallpaper(it) }
                4 -> host.clearWallpaper()
                5 -> showHidden(a, host, hiddenApps, prefs)
                6 -> openSafely(a, Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }.show()
    }

    private fun showHidden(a: Activity, host: LauncherHost, hidden: List<AppInfo>, prefs: PrefsStore) {
        if (hidden.isEmpty()) {
            Toast.makeText(a, "Nenhum app oculto", Toast.LENGTH_SHORT).show()
            return
        }
        builder(a).setTitle("Toque para reexibir")
            .setItems(hidden.map { it.label }.toTypedArray()) { _, i ->
                prefs.setHidden(hidden[i].key, false)
                host.refresh()
            }.show()
    }

    private fun prompt(a: Activity, title: String, hint: String, onOk: (String) -> Unit) {
        val et = EditText(a).apply {
            this.hint = hint
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            setSingleLine()
            setTextColor(ContextCompat.getColor(a, R.color.text_primary))
            setHintTextColor(ContextCompat.getColor(a, R.color.text_secondary))
        }
        builder(a).setTitle(title).setView(et)
            .setPositiveButton("OK") { _, _ ->
                et.text.toString().trim().takeIf { it.isNotEmpty() }?.let(onOk)
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }
}
