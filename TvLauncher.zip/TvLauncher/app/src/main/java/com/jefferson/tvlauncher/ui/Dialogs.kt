package com.jefferson.tvlauncher.ui

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.text.InputType
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import com.jefferson.tvlauncher.R
import com.jefferson.tvlauncher.data.AppCategory
import com.jefferson.tvlauncher.data.AppInfo
import com.jefferson.tvlauncher.data.PrefsStore

/** Ações que os menus pedem à tela principal. */
interface LauncherHost {
    fun refresh()
    fun changeCity(name: String)
    fun setWallpaper(url: String)
    fun clearWallpaper()
}

private fun builder(a: Activity) = AlertDialog.Builder(a, R.style.TvDialog)

private fun openSafely(a: Activity, intent: Intent) {
    try {
        a.startActivity(intent)
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(a, "Não disponível neste aparelho", Toast.LENGTH_SHORT).show()
    } catch (e: SecurityException) {
        Toast.makeText(a, "O sistema bloqueou esta ação", Toast.LENGTH_SHORT).show()
    }
}

/** Menu de um app: favorito, categoria, ocultar, dados e desinstalar. */
object AppMenu {

    fun show(a: Activity, app: AppInfo, prefs: PrefsStore, onChanged: () -> Unit) {
        val items = arrayOf(
            if (app.isFavorite) "Desafixar dos favoritos" else "Fixar nos favoritos",
            "Mover para categoria…",
            "Ocultar da tela inicial",
            "Dados e informações do app",
            "Desinstalar"
        )
        builder(a).setTitle(app.label).setItems(items) { _, i ->
            when (i) {
                0 -> { prefs.toggleFavorite(app.key); onChanged() }
                1 -> pickCategory(a, app, prefs, onChanged)
                2 -> { prefs.setHidden(app.key, true); onChanged() }
                3 -> openSafely(a, Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.parse("package:${app.packageName}")))
                4 -> openSafely(a, Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.packageName}")))
            }
        }.show()
    }

    private fun pickCategory(a: Activity, app: AppInfo, prefs: PrefsStore, onChanged: () -> Unit) {
        val cats = AppCategory.values()
        val items = cats.map { it.label }.toTypedArray() + "Automático (padrão)"
        builder(a).setTitle("Categoria de ${app.label}").setItems(items) { _, i ->
            prefs.setCategory(app.key, cats.getOrNull(i))
            onChanged()
        }.show()
    }
}

/** Menu "Ajustes" do launcher. */
object SettingsMenu {

    fun show(a: Activity, host: LauncherHost, hiddenApps: List<AppInfo>, prefs: PrefsStore) {
        val items = arrayOf(
            "Cidade do clima (${prefs.location()?.city ?: "automática"})",
            "Papel de parede por URL",
            "Remover papel de parede",
            "Apps ocultos (${hiddenApps.size})",
            "Botão Home: ativar Acessibilidade"
        )
        builder(a).setTitle("Ajustes").setItems(items) { _, i ->
            when (i) {
                0 -> prompt(a, "Cidade", "Ex.: São Paulo") { host.changeCity(it) }
                1 -> prompt(a, "URL da imagem (JPG/PNG)", "https://…") { host.setWallpaper(it) }
                2 -> host.clearWallpaper()
                3 -> showHidden(a, host, hiddenApps, prefs)
                4 -> openSafely(a, Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }.show()
    }

    private fun showHidden(a: Activity, host: LauncherHost, hidden: List<AppInfo>, prefs: PrefsStore) {
        if (hidden.isEmpty()) {
            Toast.makeText(a, "Nenhum app oculto", Toast.LENGTH_SHORT).show()
            return
        }
        builder(a).setTitle("Toque para reexibir")
            .setItems(hidden.map { it.label }.toTypedArray()) { _, i ->
                prefs.setHidden(hidden[i].key, false)
                host.refresh()
            }.show()
    }

    private fun prompt(a: Activity, title: String, hint: String, onOk: (String) -> Unit) {
        val et = EditText(a).apply {
            this.hint = hint
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            setSingleLine()
            setTextColor(ContextCompat.getColor(a, R.color.text_primary))
            setHintTextColor(ContextCompat.getColor(a, R.color.text_secondary))
        }
        builder(a).setTitle(title).setView(et)
            .setPositiveButton("OK") { _, _ ->
                et.text.toString().trim().takeIf { it.isNotEmpty() }?.let(onOk)
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }
}
