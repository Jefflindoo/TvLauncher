package com.jefferson.tvlauncher.data

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable

/**
 * Varre o PackageManager. Ícones e banners viram Bitmaps pequenos (128px / 256x144) UMA vez e ficam
 * em cache: rolagem mais leve, menos RAM que Drawables vetoriais e recarga quase instantânea.
 */
class AppRepository(private val context: Context) {

    private class Cached(val icon: Bitmap, val banner: Bitmap?)

    private val cache = HashMap<String, Cached>()

    /** Chamar quando um pacote for atualizado/removido para refazer o ícone dele. */
    fun invalidate(packageName: String) {
        synchronized(cache) { cache.keys.removeAll { it.startsWith("$packageName/") } }
    }

    /** Pesado: chame fora da main thread. */
    fun load(): List<AppInfo> {
        val pm = context.packageManager
        val result = ArrayList<AppInfo>()
        val leanbackPackages = HashSet<String>()
        val seen = HashSet<String>()

        fun collect(category: String, skipKnownPackages: Boolean) {
            val intent = Intent(Intent.ACTION_MAIN).addCategory(category)
            for (ri in pm.queryIntentActivities(intent, 0)) {
                try {
                    val ai = ri.activityInfo ?: continue
                    if (ai.packageName == context.packageName) continue
                    if (skipKnownPackages && ai.packageName in leanbackPackages) continue
                    if (!skipKnownPackages) leanbackPackages.add(ai.packageName)
                    val cn = ComponentName(ai.packageName, ai.name)
                    val key = cn.flattenToString()
                    if (!seen.add(key)) continue

                    val c = synchronized(cache) { cache[key] }
                        ?: build(pm, ri).also { synchronized(cache) { cache[key] = it } }

                    result += AppInfo(
                        label = ri.loadLabel(pm).toString(),
                        packageName = ai.packageName,
                        component = cn,
                        icon = c.icon,
                        banner = c.banner,
                        autoCategory = Categorizer.detect(ai.applicationInfo)
                    )
                } catch (e: Exception) {
                    // App com recurso quebrado: ignora só ele, o launcher continua.
                }
            }
        }

        collect(Intent.CATEGORY_LEANBACK_LAUNCHER, skipKnownPackages = false)
        collect(Intent.CATEGORY_LAUNCHER, skipKnownPackages = true)

        synchronized(cache) { cache.keys.retainAll(seen) } // libera apps desinstalados
        return result.sortedBy { it.label.lowercase() }
    }

    private fun build(pm: PackageManager, ri: ResolveInfo): Cached {
        val icon = toBitmap(ri.loadIcon(pm), 128, 128)
        val banner = try {
            ri.activityInfo.loadBanner(pm)?.let { toBitmap(it, 256, 144) }
        } catch (e: Exception) {
            null
        }
        return Cached(icon, banner)
    }

    private fun toBitmap(d: Drawable, w: Int, h: Int): Bitmap {
        val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        d.setBounds(0, 0, w, h)
        d.draw(Canvas(b))
        return b
    }
}
