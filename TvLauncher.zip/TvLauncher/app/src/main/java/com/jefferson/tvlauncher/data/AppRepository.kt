package com.jefferson.tvlauncher.data

import android.content.ComponentName
import android.content.Context
import android.content.Intent

class AppRepository(private val context: Context) {

    /** Pesado (carrega ícones): chame fora da main thread. */
    fun load(): List<AppInfo> {
        val pm = context.packageManager
        val result = ArrayList<AppInfo>()
        val leanbackPackages = HashSet<String>()
        val seenComponents = HashSet<String>()

        fun collect(category: String, skipKnownPackages: Boolean) {
            val intent = Intent(Intent.ACTION_MAIN).addCategory(category)
            for (ri in pm.queryIntentActivities(intent, 0)) {
                val ai = ri.activityInfo ?: continue
                if (ai.packageName == context.packageName) continue
                if (skipKnownPackages && ai.packageName in leanbackPackages) continue
                val cn = ComponentName(ai.packageName, ai.name)
                if (!seenComponents.add(cn.flattenToString())) continue
                if (!skipKnownPackages) leanbackPackages.add(ai.packageName)
                result += AppInfo(
                    label = ri.loadLabel(pm).toString(),
                    packageName = ai.packageName,
                    component = cn,
                    icon = ri.loadIcon(pm),
                    autoCategory = Categorizer.detect(ai.applicationInfo)
                )
            }
        }

        // 1) Apps feitos para TV  2) apps "de celular" instalados por sideload (só LAUNCHER)
        collect(Intent.CATEGORY_LEANBACK_LAUNCHER, skipKnownPackages = false)
        collect(Intent.CATEGORY_LAUNCHER, skipKnownPackages = true)

        return result.sortedBy { it.label.lowercase() }
    }
}
