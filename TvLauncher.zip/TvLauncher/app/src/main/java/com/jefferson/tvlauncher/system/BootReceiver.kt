package com.jefferson.tvlauncher.system

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.jefferson.tvlauncher.ui.MainActivity

/** Abre o launcher assim que a TV termina de iniciar. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            context.startActivity(
                Intent(context, MainActivity::class.java)
                    .addCategory(Intent.CATEGORY_HOME)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
    }
}
