# Meu Launcher para Google TV / Chromecast (Kotlin nativo, v2)

## Por que nativo (e não WebView)
Chromecast tem pouca RAM/CPU. WebView carrega um navegador inteiro e o foco por D-Pad em HTML é frágil.
Aqui: RecyclerView + XML, sem bibliotecas pesadas, ícones carregados em background, wallpaper
decodificado reduzido (RGB_565), rede por callback (sem polling), clima a cada 30 min só com a tela visível.

## Estrutura
- `data/`   AppRepository (PackageManager), Categorizer, PrefsStore (favoritos/ocultos/categorias/cidade),
            WeatherRepository (Open-Meteo, sem chave), WallpaperLoader
- `system/` NetworkMonitor, HomeKeyService (Acessibilidade), BootReceiver
- `ui/`     MainActivity, AppAdapter (zoom + borda no foco), Dialogs (menu do app e Ajustes)

## Ciclo de vida
- onCreate: monta UI, abas, carrega apps/wallpaper; loop de clima com repeatOnLifecycle(STARTED).
- onStart/onStop: registra/cancela receiver de instalação/remoção de apps e o monitor de rede.
- onNewIntent: Home com launcher aberto -> volta para "Todos" e foca o primeiro app.
- Boot: BootReceiver abre o launcher; HomeKeyService reabre ao detectar o launcher do Google.

## Controle remoto
OK = abrir app | segurar OK (ou MENU) = menu: favorito, categoria, ocultar, dados do app, desinstalar
Voltar = sai da categoria / volta ao topo.

## Compilar
Android Studio > abrir esta pasta > Build > Build APK(s) -> app/build/outputs/apk/debug/app-debug.apk

## Instalar
Na TV: Configurações > Sistema > Sobre > 7 toques em "Build"; ative Depuração USB/ADB.
    adb connect IP_DA_TV:5555
    adb install -r app-debug.apk

## Home + iniciar ao ligar (do mais robusto ao mais simples)
1) Desativar o launcher do Google (reversível; troque disable-user por enable para desfazer):
    adb shell pm disable-user --user 0 com.google.android.apps.tv.launcherx
    adb shell pm disable-user --user 0 com.google.android.tvrecommendations
   Com ele desativado o seu app é o único HOME: Home e boot passam a abrir o seu launcher.
2) Complemento (se preferir manter o launcher do Google ativo):
    adb shell appops set com.jefferson.tvlauncher SYSTEM_ALERT_WINDOW allow
    adb shell settings put secure enabled_accessibility_services com.jefferson.tvlauncher/com.jefferson.tvlauncher.system.HomeKeyService
    adb shell settings put secure accessibility_enabled 1
   (Pela interface: Ajustes > "Botão Home: ativar Acessibilidade". Em Android 13+ o botão pode vir
   bloqueado para apps instalados por fora da loja; por ADB funciona.)
   Limite: muitos aparelhos não entregam a tecla HOME a serviços de acessibilidade, então o serviço também
   reabre o launcher quando a janela do launcher do Google aparece (pode piscar rapidamente).

## Papel de parede HD
- Via ADB: adb push foto.jpg /sdcard/Android/data/com.jefferson.tvlauncher/files/wallpaper.jpg
- Ou: Ajustes > Papel de parede por URL.

## Clima
Open-Meteo, sem chave/anúncios. Sem cidade definida, usa localização aproximada pelo IP (ipwho.is).
Defina a cidade em Ajustes > Cidade do clima.
